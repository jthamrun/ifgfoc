from django.apps import AppConfig


class IfgfocConfig(AppConfig):
    name = 'ifgfoc'
